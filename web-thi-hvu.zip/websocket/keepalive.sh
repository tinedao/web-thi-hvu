#!/bin/bash
# keepalive.sh - Giữ máy chủ WebSocket luôn chạy trên cổng 127.0.0.1:8085 (hosting cPanel AZDIGI)
#
# Lý do: Node.js App của cPanel (LiteSpeed/Passenger) tự tắt tiến trình khi "rảnh",
# vì kết nối WebSocket đi thẳng qua .htaccess -> 127.0.0.1:8085 nên nó không tính là có request.
# Khi tiến trình bị tắt, cổng 8085 chết -> trình duyệt báo lỗi kết nối WebSocket.
#
# Cài đặt trong cPanel -> Cron Jobs, chạy mỗi phút (* * * * *):
#   /bin/bash $HOME/public_html/websocket/keepalive.sh >/dev/null 2>&1
#
# Mỗi lần cron gọi, script canh cổng suốt ~55 giây (kiểm tra mỗi 5 giây), nên server
# bị tắt lúc nào cũng được bật lại trong vòng vài giây. Gọi với tham số "once" để chỉ kiểm tra 1 lần.

DIR="$(cd "$(dirname "$0")" && pwd)"
PORT="${WS_PORT:-8085}"
DATA_DIR="$DIR/../data"
LOG="$DATA_DIR/ws-server.log"
INTERVAL=5
DURATION=55

mkdir -p "$DATA_DIR"

# Tìm Node.js: ưu tiên virtualenv do "Setup Node.js App" tạo, sau đó tới các bản alt-nodejs của CloudLinux
find_node() {
    local found=""
    for c in "$HOME"/nodevenv/*/websocket/*/bin/node "$HOME"/nodevenv/websocket/*/bin/node \
             /opt/alt/alt-nodejs*/root/usr/bin/node "$(command -v node 2>/dev/null)"; do
        if [ -x "$c" ]; then found="$c"; fi
    done
    echo "$found"
}

is_up() {
    (exec 3<>"/dev/tcp/127.0.0.1/$PORT") 2>/dev/null
}

start_server() {
    local node_bin
    node_bin="$(find_node)"
    if [ -z "$node_bin" ]; then
        echo "[$(date '+%F %T')] Không tìm thấy node" >> "$LOG"
        return 1
    fi
    echo "[$(date '+%F %T')] Cổng $PORT chết, khởi động lại bằng $node_bin" >> "$LOG"
    cd "$DIR" || return 1
    # Bỏ PORT của Passenger (nếu có) để server nghe đúng cổng TCP 8085.
    # setsid + nohup: tách hẳn khỏi cron/PHP để không bị tắt theo tiến trình cha.
    env -u PORT WS_PORT="$PORT" WS_HOST=127.0.0.1 setsid nohup "$node_bin" "$DIR/websocket-server.js" \
        >> "$LOG" 2>&1 < /dev/null &
    # Chờ server mở cổng để vòng kiểm tra sau không khởi động trùng
    for _ in 1 2 3 4 5 6; do
        sleep 1
        is_up && return 0
    done
    return 0
}

# Giữ log không phình quá ~2MB
if [ -f "$LOG" ] && [ "$(wc -c < "$LOG")" -gt 2097152 ]; then
    tail -c 524288 "$LOG" > "$LOG.tmp" && mv "$LOG.tmp" "$LOG"
fi

if [ "$1" = "once" ]; then
    is_up || start_server
    exit 0
fi

# Chỉ cho 1 bản canh gác chạy tại một thời điểm (cron gọi mỗi phút có thể chồng nhau)
exec 9>"$DATA_DIR/ws-keepalive.lock"
if command -v flock >/dev/null 2>&1; then
    flock -n 9 || exit 0
fi

END=$((SECONDS + DURATION))
while [ "$SECONDS" -lt "$END" ]; do
    is_up || start_server
    sleep "$INTERVAL"
done
exit 0
